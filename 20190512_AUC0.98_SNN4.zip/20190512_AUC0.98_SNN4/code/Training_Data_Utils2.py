import cv2
import PIL.Image as Image
import numpy as np
import xml.dom.minidom as minidom
from random import sample,choice
from keras.utils import Sequence
# from keras.applications.vgg19 import preprocess_input
from imgaug import augmenters as iaa
from glob import glob
from sklearn.model_selection import train_test_split

'''
批量产生训练集数据；
'''
def loadImage(filename):
    # first we read the image, as a raw file to the buffer
    # https://blog.csdn.net/tanlangqie/article/details/79560296
    img = Image.open(filename)
    img = np.array(img)
    return img

class TrainingSequenceData(Sequence):
    def __init__(self, image_file_pairs, labels, batch_size = 32):
        '''
        :param filenames:装有待测图像的文件名的列表
        :param batch_size: 每批的图像样本个数
        '''
        # self.filenames = filenames
        self.batch_size = batch_size

        self.image_file_pairs, self.labels = image_file_pairs, labels

        self.normal_seq = iaa.Sequential([
            iaa.Fliplr(0.5), # horizontal flips
            iaa.Flipud(0.5),
            iaa.Affine(
                scale={'x': (1.0, 1.2), 'y': (1.0, 1.2)}
            )
        ], random_order=True)

    def __len__(self):
        '''
        注：需要将len（filenames）做修改，改成组合的样本对的个数。
        :return:
        '''
        return int(len(self.image_file_pairs)/self.batch_size)

    def __getitem__(self, idx):
        '''
        迭代器，返回每批图像对的array和标签
        :param idx:
        :return:
        '''
        # self.image_file_pairs, self.labels = self.siamese_pairs()

        batch_x = self.image_file_pairs[idx * self.batch_size:(idx + 1) * self.batch_size]
        batch_y = self.labels[idx * self.batch_size:(idx + 1) * self.batch_size]

        a = []
        b = []
        c = []
        for i in range(len(batch_x)):
            a.append(self.read_im(batch_x[i][0]))
            b.append(self.read_im(batch_x[i][1]))
            c.append(batch_y[i])

        # X_train, X_test, y_train, y_test = train_test_split(p, c,
        #                                                     test_size=0.1, random_state=42)

        a = np.array(a).astype('float32') / 255
        b = np.array(b).astype('float32') / 255
        c = np.array(c)

        return [a, b], c
        # return np.array([a,b]), c


    def file_id_mapping(self):
        '''
        为每个图像标注正常样本和异常样本；
        :return: 文件 加 标签 的 字典
        '''
        files_id_mapping = {f: 'normal' if f[0].split('\\')[1] == 'Reference' else 'defect' for f in self.filenames}
        return files_id_mapping

    def read_im(self, f):
        '''
        读取图像文件，对图像文件做在线图像增强；
        :param f: 文件名
        :return:
        '''
        im = cv2.imread(f)
        # 图像尺寸
        h, w, _ = im.shape
        # 图像灰度化
        im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
        # 图像增强
        im = self.normal_seq.augment_image(im)
        return im
        # im = preprocess_input(im)


def siamese_pairs():
    '''
        生成孪生样本对；
        :return:
    '''
    image_file_pairs = []
    labels = []

    reference_files = glob('data/Reference/*.jpg')
    d1 = glob('data/BrokenEnd/*.jpg')
    d2 = glob('data/Hole/*.jpg')
    d3 = glob('data/Knots/*.jpg')
    d4 = glob('data/NettingMultiple/*.jpg')
    d5 = glob('data/ThickBar/*.jpg')
    d6 = glob('data/ThinBar/*.jpg')
    defect_files = d1 + d2 + d3 + d4 + d5 +d6

    np.random.shuffle(reference_files)
    np.random.shuffle(defect_files)

    avg = len(reference_files) / float(2)
    out = []
    last = 0.0
    while last < len(reference_files):
        out.append(reference_files[int(last):int(last + avg)])
        last += avg

    normals0 = out[0]
    normals1 = out[1]

    for num in range(10):
        for i in range(min(len(normals0), len(normals1), len(defect_files))):
            if (i % 2) == 0:
                image_file_pairs.append([normals0[(num + 1) * int(len(normals0) / 10)],
                                             normals1[i]])
                labels.append(0)
            else:
                image_file_pairs.append([normals0[(num + 1) * int(len(normals0) / 10)],
                                             defect_files[i]])
                labels.append(1)
    return image_file_pairs, labels


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    from glob import glob
    from collections import defaultdict
    from sklearn.utils import shuffle
    def siamese_pairs():
        '''
        生成孪生样本对；
        :return:
        '''
        image_file_pairs = []
        labels = []

        reference_files = glob('data/Reference/*.jpg')
        d1 = glob('data/BrokenEnd/*.jpg')
        d2 = glob('data/Hole/*.jpg')
        d3 = glob('data/Knots/*.jpg')
        d4 = glob('data/NettingMultiple/*.jpg')
        d5 = glob('data/ThickBar/*.jpg')
        d6 = glob('data/ThinBar/*.jpg')
        defect_files = d1 + d2 + d3 + d4 + d5 +d6

        np.random.shuffle(reference_files)
        np.random.shuffle(defect_files)

        avg = len(reference_files) / float(2)
        out = []
        last = 0.0
        while last < len(reference_files):
            out.append(reference_files[int(last):int(last + avg)])
            last += avg

        normals0 = out[0]
        normals1 = out[1]

        for num in range(20):
            for i in range(min(len(normals0), len(normals1), len(defect_files))):
                if (i % 2) == 0:
                    image_file_pairs.append([normals0[(num + 1) * int(len(normals0) / 20)],
                                             normals1[i]])
                    labels.append(0)
                else:
                    image_file_pairs.append([normals0[(num + 1) * int(len(normals0) / 20)],
                                             defect_files[i]])
                    labels.append(1)
        return image_file_pairs, labels


    X, Y = siamese_pairs()
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.15)


    gen_train = TrainingSequenceData(x_train, y_train, 64)
    gen_val = TrainingSequenceData(x_test, y_test, 32)
    for im, l in gen_train:
        a = 1
