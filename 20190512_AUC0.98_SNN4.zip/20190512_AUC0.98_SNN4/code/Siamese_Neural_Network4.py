from keras import regularizers
from keras.optimizers import Adam, RMSprop
from keras.engine.topology import Input
from keras.layers import Activation, Add, BatchNormalization, Concatenate, \
    Conv2D, Dense, Flatten, GlobalMaxPooling2D, Lambda, MaxPooling2D, Reshape, Dropout
from keras.models import Model, Sequential
import keras.backend as K
'''
更改模型，模型使用3层卷积层；

卷积层 1：卷积核大小 3*3，卷积核移动步长 1，卷积核个数 32，池化大小 2*2，池化步长 2，池化类型为最大池化，激活函数 ReLU。

卷积层 2：卷积核大小 3*3，卷积核移动步长 1，卷积核个数 64，池化大小 2*2，池化步长 2，池化类型为最大池化，激活函数 ReLU。

卷积层 3：卷积核大小 3*3，卷积核移动步长 1，卷积核个数 32，池化大小 2*2，池化步长 2，池化类型为最大池化，激活函数 ReLU。

全连接层：隐藏层单元数 256，激活函数 ReLU。

相似度度量层：隐藏层单元数 50；

'''
img_shape = (64, 64, 3)
kernel_size = (3, 3)
pool_size = (2, 2)
epochs = 20
batch_size = 256
nb_filters = 32
img_rows, img_cols = 64, 64
if K.image_data_format() == 'channels_first':
    shape_ord = (3, img_rows, img_cols)
else:
    shape_ord = (img_rows, img_cols, 3)
def branch_model_CNN(shape_ord):
    model = Sequential()

    model.add(Conv2D(nb_filters, kernel_size=kernel_size, input_shape=shape_ord, name='Conv1'))
    model.add(Activation('relu', name='Act1'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling1'))

    model.add(Conv2D(2 * nb_filters, kernel_size=kernel_size, name='Conv2'))
    model.add(Activation('relu', name='Act2'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling2'))

    model.add(Conv2D(nb_filters, kernel_size=kernel_size, name='Conv3'))
    model.add(Activation('relu', name='Act3'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling3'))

    # model.add(Dropout(0.25, name='Drop1'))

    model.add(Flatten(name='Flatten'))

    model.add(Dense(128, name='Dense1'))
    model.add(Activation('relu', name='Act4'))

    model.add(Dropout(0.5, name='Drop2'))

    model.add(Dense(50, name='Dense2'))
    return model

def euclidean_distance(vects):
    x, y = vects
    sum_square = K.sum(K.square(x - y), axis=1, keepdims=True)
    return K.sqrt(K.maximum(sum_square, K.epsilon()))

def eucl_dist_output_shape(shapes):
    shape1, shape2 = shapes
    return (shape1[0], 1)

def build_model(lr, l2, activation='sigmoid'):
    ############
    # Branch Model
    ############
    regul = regularizers.l2(l2)
    optim = Adam(lr=lr)
    kwargs = {'padding':'same', 'kernel_regularizer':regul}

    branch_model = branch_model_CNN(shape_ord)


    ############
    # HEAD MODEL
    ############
    mid = 32
    xa_inp = Input(shape=branch_model.output_shape[1:])
    xb_inp = Input(shape=branch_model.output_shape[1:])
    x1 = Lambda(lambda x: x[0] * x[1])([xa_inp, xb_inp])
    x2 = Lambda(lambda x: x[0] + x[1])([xa_inp, xb_inp])
    x3 = Lambda(lambda x: K.abs(x[0] - x[1]))([xa_inp, xb_inp])
    x4 = Lambda(lambda x: K.square(x))(x3)
    x = Concatenate()([x1, x2, x3, x4])
    x = Reshape((4, branch_model.output_shape[1], 1), name='reshape1')(x)

    # Per feature NN with shared weight is implemented using CONV2D with appropriate stride.
    x = Conv2D(mid, (4, 1), activation='relu', padding='valid')(x)
    x = Reshape((branch_model.output_shape[1], mid, 1))(x)
    x = Conv2D(1, (1, mid), activation='linear', padding='valid')(x)
    x = Flatten(name='flatten')(x)

    # Weighted sum implemented as a Dense layer.
    x = Dense(1, use_bias=True, activation=activation, name='weighted-average')(x)
    head_model = Model([xa_inp, xb_inp], x, name='head')

    ########################
    # SIAMESE NEURAL NETWORK
    ########################
    # Complete model is constructed by calling the branch model on each input image,
    # and then the head model on the resulting 512-vectors.
    img_a = Input(shape=img_shape)
    img_b = Input(shape=img_shape)
    xa = branch_model(img_a)
    xb = branch_model(img_b)
    x = head_model([xa, xb])
    model = Model([img_a, img_b], x)
    model.compile(optim, loss='binary_crossentropy', metrics=['binary_crossentropy', 'acc'])
    return model, branch_model, head_model



if __name__ == '__main__':
    # model, branch_model, head_model = build_model(64e-5, 0)

    base_network = branch_model_CNN(shape_ord)

    input_a = Input(shape=shape_ord)
    input_b = Input(shape=shape_ord)
    processed_a = base_network(input_a)
    processed_b = base_network(input_b)

    distance = Lambda(euclidean_distance,
                      output_shape=eucl_dist_output_shape)([processed_a, processed_b])

    model = Model([input_a, input_b], distance)
    # model.summary()
    print('Generate the model...')
    from keras.callbacks import ModelCheckpoint, ReduceLROnPlateau,EarlyStopping
    from Training_Data_Utils2 import TrainingSequenceData, siamese_pairs
    from keras.optimizers import RMSprop
    from contrastiveLoss import *
    from siameseNN3 import *
    from sklearn.model_selection import train_test_split

    X, Y = siamese_pairs()
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.15)

    gen_train = TrainingSequenceData(x_train, y_train, 128)
    gen_val = TrainingSequenceData(x_test, y_test, 64)

    # all_gen = TrainingSequenceData(batch_size = 128)
    reduce_lr = ReduceLROnPlateau(monitor='loss', factor=0.5, patience=3)
    checkpoint = ModelCheckpoint('snn_model.h5', monitor='val_loss', verbose=1, save_best_only=True, mode='min')
    early = EarlyStopping(monitor="val_loss", mode="min", patience=5)

    # callbacks_list = [reduce_lr, checkpoint, early]
    # callbacks_list = [reduce_lr, checkpoint]
    callbacks_list = [reduce_lr]

    def accuracy(y_true, y_pred):
        '''Compute classification accuracy with a fixed threshold on distances.
        '''
        return K.mean(K.equal(y_true, K.cast(y_pred > 0.5, y_true.dtype)))


    # history = model.fit_generator(all_gen, epochs=60, verbose=1,
    #                               # workers=4, use_multiprocessing=True,
    #                               callbacks=callbacks_list, steps_per_epoch=500)

    rms = RMSprop()
    model.compile(loss=contrastive_loss, optimizer=rms, metrics=[accuracy, 'mae'])
    history = model.fit_generator(gen_train, epochs=20, verbose=1,
                                  # workers=4, use_multiprocessing=True,
                                  callbacks=callbacks_list, steps_per_epoch=100,
                                  validation_data=gen_val, validation_steps=100)
    model.save('scnn_train_val_origianl_3layers.h5')

    # test model
    import PIL.Image as Image
    path_a = 'test/p_0_1.jpg'
    path_b = 'test/p_0_2.jpg'
    path_c = 'template/p_0_1.jpg'
    path_d = 'data/Reference/p_0_1.jpg'
    path_e = 'data/Reference/p_0_2.jpg'
    path_f = 'data/BrokenEnd/p_0_293.jpg'
    a = np.array(Image.open(path_a)).astype('float32') / 255
    b = np.array(Image.open(path_b)).astype('float32') / 255
    c = np.array(Image.open(path_c)).astype('float32') / 255
    d = np.array(Image.open(path_d)).astype('float32') / 255
    e = np.array(Image.open(path_e)).astype('float32') / 255
    f = np.array(Image.open(path_f)).astype('float32') / 255
    a = a.reshape((1,64,64,3))
    b = b.reshape((1, 64, 64, 3))
    c = c.reshape((1, 64, 64, 3))
    d = d.reshape((1, 64, 64, 3))
    e = e.reshape((1, 64, 64, 3))
    f = f.reshape((1, 64, 64, 3))

    print(model.predict([a,c]))
    print(model.predict([b,c]))

    from testImageCutting2 import *

    test_img0 = test_image[1][0]
    test_img3 = test_image[1][3]

    # 5. Abnormaly Detection in clothing picture

    from template import template
    from matplotlib import pyplot as plt

    defect_type_list = test_files_path
    for idx in range(len(defect_type_list)):
        dissimilarity_score = []
        for i in range(test_image[idx].shape[0]):
            score_list = []
            for j in range(template.shape[0]):
                score = model.predict([template[j].reshape(1, 64, 64, 3),
                                       test_image[idx][i].reshape(1, 64, 64, 3)])
                score_list.append(score)
            dissimilarity_score.append(np.mean(np.array(score_list)))

        # 5.3 show the results
        plt.subplot(3, 1, 1)
        plt.imshow(loadImage(test_files_path[idx]))
        plt.title(defect_type_list[idx])
        plt.axis('off')
        for jm in range(test_image[idx].shape[0]):
            plt.subplot(3, 16, 17 + jm)
            plt.imshow(test_image[idx][jm])
            plt.axis('off')
        plt.subplot(3, 1, 3)
        plt.plot(dissimilarity_score, 'c*-', label='score')
        plt.plot(np.array([0.5 for i in range(len(dissimilarity_score))]), color='r', linestyle='dashed',
                 label='threshold')
        plt.legend()
        plt.xlabel('The idx of the sub-picture')
        plt.ylabel('Dissimilarity score')
        fig = plt.gcf()
        # plt.savefig('result/' + defect_type_list[idx].split('\\')[2])
        plt.show()

    # virsulatization
    history_dict = history.history
    loss_values = history_dict['loss']
    val_loss_values = history_dict['val_loss']
    epochs = range(1, (len(history.history['val_accuracy']) + 1))
    # plt.figure(figsize=(20,10))
    plt.subplot(2, 1, 1)
    plt.plot(epochs, loss_values, 'bo', label='Training loss')
    plt.plot(epochs, val_loss_values, 'b', label='Validation loss')
    plt.title('Training and validation loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    # ACCURACY Learning Curves
    plt.subplot(2, 1, 2)
    history_dict = history.history
    acc_values = history_dict['accuracy']
    val_acc_values = history_dict['val_accuracy']
    epochs = range(1, (len(history.history['accuracy']) + 1))
    plt.plot(epochs, acc_values, 'bo', label='Training Acc')
    plt.plot(epochs, val_acc_values, 'b', label='Validation Acc')
    plt.title('Training and validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()

    # 测试集auc
    defect_type_list = test_files_path
    test_score = [[] for i in range(len(defect_type_list))]
    for idx in range(len(defect_type_list)):
        dissimilarity_score = test_score[idx]
        for i in range(test_image[idx].shape[0]):
            score_list = []
            for j in range(template.shape[0]):
                score = model.predict([template[j].reshape(1, 64, 64, 3),
                                       test_image[idx][i].reshape(1, 64, 64, 3)])
                score_list.append(score)
            # dissimilarity_score.append(np.mean(np.array(score_list)))
            dissimilarity_score.append(np.max(np.array(score_list)))
    test_score = np.array(test_score)
    test_score = test_score.reshape(-1, 1)
    # # 给出待测图像的真实标签
    # # from scipy import misc
    # # for i in range(test_image.shape[0]):
    # #     for j in range(test_image.shape[1]):
    # #         a = test_image[i][j]
    # #         misc.imsave('test/t{}_{}.jpg'.format(i,j), a)
    # test_label = [0,0,0,1,0,0,0,1, #t1
    # 0,0,0,1,0,0,0,0,
    # 0,0,0,1,0,0,0,1, #tt1
    # 0,0,0,1,0,0,0,1,
    # 0,0,0,0,0,0,0,0, #b1
    # 1,1,1,0,0,0,0,0,
    # 0,0,0,0,0,0,1,1, #h5
    # 0,0,0,0,1,0,0,0,
    # 0,1,1,1,1,0,0,1, #k3
    # 1,0,1,0,0,1,1,0,
    # 0,1,1,0,1,0,0,0, #n1
    # 0,0,0,0,0,0,0,0,
    # 0,1,1,0,1,0,0,0, #test1
    # 0,1,1,0,0,1,1,1,
    # 1,1,1,0,0,0,1,1, #test4
    # 0,1,0,0,1,1,0,0,
    # 0,0,0,0,0,0,0,0, #p1
    # 0,0,0,0,0,0,0,0]
    # test_label = np.array(test_label)
    # test_label = test_label.reshape(-1,1)
    # p_test = Performance(test_label, test_score)
    # p_test.roc_plot()
    from test_labels import test_labels
    from Performance import Performance

    test_labels = np.array(test_labels)
    p_test = Performance(test_labels, test_score)
    p_test.get_confusion_matrix()

    fpr, tpr, threshold = roc_curve(test_labels, test_score)  ###计算真正率和假正率
    roc_auc = auc(fpr, tpr)  ###计算auc的值
    plt.figure()
    lw = 2
    plt.figure(figsize=(10, 10))
    plt.plot(fpr, tpr, color='darkorange',
             lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)  ###假正率为横坐标，真正率为纵坐标做曲线
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example in test set')
    plt.legend(loc="lower right")
    plt.show()


