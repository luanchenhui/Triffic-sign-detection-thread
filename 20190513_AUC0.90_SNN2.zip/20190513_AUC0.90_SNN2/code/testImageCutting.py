from PIL import Image
import os
import  numpy as np
from glob import glob
'''
将一张测试图切割成16张子图。
'''
test_files_path = glob('database/dot-pattern/*/*.bmp')
# enhanced_type_list = ['t1','tt1','b1','h5','k3','n1','test1','test4','p1']
# test_image_list = [[] for i in range(len(enhanced_type_list))]
test_image_list = [[] for i in range(len(test_files_path))]

for fold_idx in range(len(test_files_path)):

        name = test_files_path[fold_idx]
        img = Image.open(name)
        k = 1
        for i in range(4):
            for j in range(4):
                img1 = img.crop((i * 256 / 4, j * 256 / 4, (i + 1) * 256 / 4, (j + 1) * 256 / 4))
                test_image_list[fold_idx].append(np.array(img1))
                # img1.save('test/p_{}_{}.jpg'.format(fold_idx, k))
                k += 1

test_image = np.array(test_image_list)

test_image = test_image.astype('float32')

test_image /= 255