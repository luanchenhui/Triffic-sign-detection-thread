from PIL import Image
import os


enhanced_type_list = ['normal']


for fold_idx in range(len(enhanced_type_list)):
    path = 'database/dot-pattern/' + enhanced_type_list[fold_idx]
    # print('666')
    if os.path.isdir(path):
        img_names = os.listdir(path)
        # print('666')
    else:
        img_names = [path]
    for idx in range(len(img_names)):
        # print(img_name)
        img_name = img_names[idx]
        tmp_img_name = os.path.join(path, img_name)
        # print(tmp_img_name)
        img = Image.open(tmp_img_name)
        k = 1
        for i in range(4):
            for j in range(4):
                img1 = img.crop((i * 256 / 4, j * 256 / 4, (i + 1) * 256 / 4, (j + 1) * 256 / 4))
                img1.save('template/' + 'p_{}_{}.jpg'.format(idx, k))
                k += 1







        # if os.path.isdir(tmp_img_name):
        #     print('666')
        #     img = Image.open(tmp_img_name)
        #     k = 1
        #     for i in range(8):
        #         for j in range(8):
        #             img1 = img.crop((i * 256 / 8, j * 256 / 8, (i + 1) * 256 / 8, (j + 1) * 256 / 8))
        #             img1.save('data/' + data_type_list[i] + '/p{}.jpg'.format(k))
        #             k += 1


