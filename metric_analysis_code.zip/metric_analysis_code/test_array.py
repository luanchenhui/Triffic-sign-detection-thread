from PIL import Image
import os
import  numpy as np
import glob

from PIL import Image
import os
import  numpy as np
import glob


files_database = glob.glob('database/dot-pattern/*/*.bmp')

test_image_list = [[] for i in range(len(files_database))]

for fold_idx in range(len(files_database)):
    path = files_database[fold_idx]
    # print('666')
    if os.path.isdir(path):
        img_names = os.listdir(path)
        # print('666')
    else:
        img_names = [path]
    print('the No.{} is ready.'.format(fold_idx))
    for idx in range(len(img_names)):
        # print(img_name)
        img_name = img_names[idx]
        # tmp_img_name = os.path.join(path, img_name)
        # print(tmp_img_name)
        img = Image.open(img_name)

        k = 1
        for i in range(4):
            for j in range(4):
                img1 = img.crop((i * 256 / 4, j * 256 / 4, (i + 1) * 256 / 4, (j + 1) * 256 / 4))
                test_image_list[fold_idx].append(np.array(img1))
                # img1.save('test/' + 'p_{}_{}.jpg'.format(idx, k))
                k += 1


test_image = np.array(test_image_list)

test_image = test_image.astype('float32')

test_image /= 255