import glob
import numpy as np
from PIL import Image

def loadImage(filename):
    # first we read the image, as a raw file to the buffer
    # https://blog.csdn.net/tanlangqie/article/details/79560296
    img = Image.open(filename)
    img = np.array(img)
    return img

template_list = glob.glob('template/*.jpg') # 共80个
template = []
for i in range(10): # 选取10个作为模板
    template.append(loadImage(template_list[1+8*i]))

template = np.array(template)

template = template.astype('float32')

template /= 255