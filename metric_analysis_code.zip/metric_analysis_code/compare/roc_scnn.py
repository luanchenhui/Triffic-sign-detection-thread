import pandas as pd
import numpy as np
from sklearn.metrics import roc_curve, auc

data1 = pd.read_csv("Predict with scnn1.csv")
x1 = data1['probability']
y1 = data1['real label']
x1 = x1.tolist()
y1 = y1.tolist()
x1 = np.array(x1)
y1 = np.array(y1)


fpr1, tpr1, threshold1 = roc_curve(y1, x1)
roc_auc1 = auc(fpr1, tpr1)


data2 = pd.read_csv("Predict with scnn2.csv")
x2 = data2['probability']
y2 = data2['real label']
x2 = x2.tolist()
y2 = y2.tolist()
x2 = np.array(x2)
y2 = np.array(y2)


fpr2, tpr2, threshold2 = roc_curve(y2, x2)
roc_auc2 = auc(fpr2, tpr2)


data3 = pd.read_csv("Predict with scnn3.csv")
x3 = data3['probability']
y3 = data3['real label']
x3 = x3.tolist()
y3 = y3.tolist()
x3 = np.array(x3)
y3 = np.array(y3)


fpr3, tpr3, threshold3 = roc_curve(y3, x3)
roc_auc3 = auc(fpr3, tpr3)


data4 = pd.read_csv("Predict with scnn4.csv")
x4 = data4['probability']
y4 = data4['real label']
x4 = x4.tolist()
y4 = y4.tolist()
x4 = np.array(x4)
y4 = np.array(y4)


fpr4, tpr4, threshold4 = roc_curve(y4, x4)
roc_auc4 = auc(fpr4, tpr4)


data5 = pd.read_csv("Predict with scnn5.csv")
x5 = data5['probability']
y5 = data5['real label']
x5 = x5.tolist()
y5 = y5.tolist()
x5 = np.array(x5)
y5 = np.array(y5)


fpr5, tpr5, threshold5 = roc_curve(y5, x5)
roc_auc5 = auc(fpr5, tpr5)


data6 = pd.read_csv("Predict with scnn6.csv")
x6 = data6['probability']
y6 = data6['real label']
x6 = x6.tolist()
y6 = y6.tolist()
x6 = np.array(x6)
y6 = np.array(y6)


fpr6, tpr6, threshold6 = roc_curve(y6, x6)
roc_auc6 = auc(fpr6, tpr6)


data7 = pd.read_csv("Predict with scnn7.csv")
x7 = data7['probability']
y7 = data7['real label']
x7 = x7.tolist()
y7 = y7.tolist()
x7 = np.array(x7)
y7 = np.array(y7)


fpr7, tpr7, threshold7 = roc_curve(y7, x7)
roc_auc7 = auc(fpr7, tpr7)




import matplotlib.pyplot as plt
plt.figure()
lw =2
plt.figure()
plt.plot(fpr1, tpr1, lw=lw, label='SCNN1 ROC curve(area = %0.2f'%roc_auc1)
plt.plot(fpr2, tpr2, lw=lw, label='SCNN2 ROC curve(area = %0.2f'%roc_auc2)
plt.plot(fpr3, tpr3, lw=lw, label='SCNN3 ROC curve(area = %0.2f'%roc_auc3)
plt.plot(fpr4, tpr4, lw=lw, label='SCNN4 ROC curve(area = %0.2f'%roc_auc4)
plt.plot(fpr5, tpr5, lw=lw, label='SCNN5 ROC curve(area = %0.2f'%roc_auc5)
plt.plot(fpr6, tpr6, lw=lw, label='SCNN6 ROC curve(area = %0.2f'%roc_auc6)
plt.plot(fpr7, tpr7, lw=lw, label='SCNN7 ROC curve(area = %0.2f'%roc_auc7)
plt.plot([0,1], [0,1], color='navy', lw=lw, linestyle='--')
plt.legend()
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic ')
plt.show()


from Performance import Performance
p_test1 = Performance(y1, x1)
p_test1.get_confusion_matrix()