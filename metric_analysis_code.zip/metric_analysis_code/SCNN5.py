from keras import regularizers
from keras.optimizers import Adam, RMSprop
from keras.engine.topology import Input
from keras.layers import Activation, Add, BatchNormalization, Concatenate, \
    Conv2D, Dense, Flatten, GlobalMaxPooling2D, Lambda, MaxPooling2D, Reshape, Dropout
from keras.models import Model, Sequential
import keras.backend as K
'''
更改模型，模型使用3层卷积层，该模型为进行模型提升设置的基础模型；

卷积层 1：卷积核大小 3*3，卷积核移动步长 1，卷积核个数 32，池化大小 2*2，池化步长 2，池化类型为最大池化，激活函数 ReLU。

卷积层 2：卷积核大小 3*3，卷积核移动步长 1，卷积核个数 64，池化大小 2*2，池化步长 2，池化类型为最大池化，激活函数 ReLU。

卷积层 3：卷积核大小 3*3，卷积核移动步长 1，卷积核个数 32，池化大小 2*2，池化步长 2，池化类型为最大池化，激活函数 ReLU。

全连接层：隐藏层单元数 256，激活函数 ReLU。

相似度度量层：隐藏层单元数 50；

判决层用l2范数

'''
img_shape = (64, 64, 3)
kernel_size = (3, 3)
pool_size = (2, 2)
epochs = 20
batch_size = 256
nb_filters = 32
img_rows, img_cols = 64, 64
if K.image_data_format() == 'channels_first':
    shape_ord = (3, img_rows, img_cols)
else:
    shape_ord = (img_rows, img_cols, 3)
def branch_model_CNN(shape_ord):
    model = Sequential()

    model.add(Conv2D(nb_filters, kernel_size=kernel_size, input_shape=shape_ord, name='Conv1'))
    model.add(Activation('relu', name='Act1'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling1'))

    model.add(Conv2D(2 * nb_filters, kernel_size=kernel_size, name='Conv2'))
    model.add(Activation('relu', name='Act2'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling2'))

    model.add(Conv2D(nb_filters, kernel_size=kernel_size, name='Conv3'))
    model.add(Activation('relu', name='Act3'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling3'))

    # model.add(Dropout(0.25, name='Drop1'))

    model.add(Flatten(name='Flatten'))

    model.add(Dense(128, name='Dense1'))
    model.add(Activation('relu', name='Act4'))

    model.add(Dropout(0.5, name='Drop2'))

    model.add(Dense(50, name='Dense2'))
    return model

def euclidean_distance(vects):
    x, y = vects
    sum_square = K.sum(K.square(x - y), axis=1, keepdims=True)
    return K.sqrt(K.maximum(sum_square, K.epsilon()))

def eucl_dist_output_shape(shapes):
    shape1, shape2 = shapes
    return (shape1[0], 1)





if __name__ == '__main__':
    # model, branch_model, head_model = build_model(64e-5, 0)
    from Training_Data_Utils2 import TrainingSequenceData

    def loadImage(filename):
        # first we read the image, as a raw file to the buffer
        # https://blog.csdn.net/tanlangqie/article/details/79560296
        img = Image.open(filename)
        img = np.array(img)
        return img

    # 加载数据
    import pandas as pd
    from ast import literal_eval
    data = pd.read_csv("Siamese files.csv")
    x = data['siamese pairs']
    y = data['label']
    x = x.tolist()
    y = y.tolist()
    x = [literal_eval(x[i]) for i in range(len(x))]
    for i in range(len(x)):
        for j in range(2):
            x[i][j] = x[i][j].replace('\\', '/')
    gen_all = TrainingSequenceData(x, y, batch_size=128)

    # 加载模型
    base_network = branch_model_CNN(shape_ord)

    input_a = Input(shape=shape_ord)
    input_b = Input(shape=shape_ord)
    processed_a = base_network(input_a)
    processed_b = base_network(input_b)

    distance = Lambda(euclidean_distance,
                      output_shape=eucl_dist_output_shape)([processed_a, processed_b])

    model = Model([input_a, input_b], distance)
    # model.summary()
    from keras.callbacks import ModelCheckpoint, ReduceLROnPlateau, EarlyStopping
    # from Training_Data_Utils import TrainingSequenceData
    from keras.optimizers import RMSprop
    from contrastiveLoss import *


    # from siameseNN3 import *

    def loadImage(filename):
        # first we read the image, as a raw file to the buffer
        # https://blog.csdn.net/tanlangqie/article/details/79560296
        img = Image.open(filename)
        img = np.array(img)
        return img


    def accuracy(y_true, y_pred):
        '''Compute classification accuracy with a fixed threshold on distances.
        '''
        return K.mean(K.equal(y_true, K.cast(y_pred > 0.5, y_true.dtype)))


    # all_gen = TrainingSequenceData(batch_size = 128)
    reduce_lr = ReduceLROnPlateau(monitor='loss', factor=0.5, patience=3)
    checkpoint = ModelCheckpoint('snn_model.h5', monitor='val_loss', verbose=1, save_best_only=True, mode='min')
    # early = EarlyStopping(monitor="val_loss", mode="min", patience=5)

    # callbacks_list = [reduce_lr, checkpoint, early]
    # callbacks_list = [reduce_lr, checkpoint]
    callbacks_list = [reduce_lr]

    # history = model.fit_generator(all_gen, epochs=60, verbose=1,
    #                               # workers=4, use_multiprocessing=True,
    #                               callbacks=callbacks_list, steps_per_epoch=500)

    # rms = RMSprop()
    optim = Adam(lr=64e-5)
    model.compile(loss=contrastive_loss, optimizer=optim, metrics=[accuracy, 'mae'])
    history = model.fit_generator(gen_all, epochs=30, verbose=1,
                                  # workers=4, use_multiprocessing=True,
                                  callbacks=callbacks_list, steps_per_epoch=200)
    model.save('scnn5.h5')

    import PIL.Image as Image
    import numpy as np
    from testImageCutting import *
    from template import template
    from matplotlib import pyplot as plt

    # 模型预测待测数据的数值
    defect_type_list = test_files_path
    test_score = [[] for i in range(len(defect_type_list))]
    for idx in range(len(defect_type_list)):
        dissimilarity_score = test_score[idx]
        for i in range(test_image[idx].shape[0]):
            score_list = []
            for j in range(template.shape[0]):
                score = model.predict([template[j].reshape(1, 64, 64, 3),
                                       test_image[idx][i].reshape(1, 64, 64, 3)])
                score_list.append(score)
            # dissimilarity_score.append(np.mean(np.array(score_list)))
            dissimilarity_score.append(np.max(np.array(score_list)))
    test_score = np.array(test_score)
    test_score = test_score.reshape(-1, 1)

    # 存储预测值与真实值
    import pandas as pd
    from test_labels import test_labels

    test_score1 = np.array([0 if test_score[i] < 0.5 else 1 for i in range(len(test_score))])
    # files_path = glob('test/*.jpg')
    files_path = []
    for i in range(62):
        for j in range(16):
            a = 'test/p_{}_{}.jpg'.format(i, j)
            files_path.append(a)

    df = pd.DataFrame([files_path[i] for i in range(len(files_path))],
                      columns=["filename"])
    df['probability'] = test_score
    df['predict label'] = test_score1
    df['real label'] = test_labels
    df.to_csv("Predict with scnn5.csv", index=False)

    # 评估模型ROC曲线：
    from test_labels import test_labels
    from Performance import Performance
    from sklearn.metrics import roc_curve, auc

    test_labels = np.array(test_labels)
    p_test = Performance(test_labels, test_score)
    p_test.get_confusion_matrix()

    fpr, tpr, threshold = roc_curve(test_labels, test_score)  ###计算真正率和假正率
    roc_auc = auc(fpr, tpr)  ###计算auc的值

    # 存储fpr值和tpr值
    df = pd.DataFrame([i for i in range(len(fpr))],
                      columns=["index"])
    df['fpr'] = fpr
    df['tpr'] = tpr
    df['threshold'] = threshold
    df.to_csv("ROC for scnn5.csv", index=False)

    # 存储训练集的损失和正确率
    history_dict = history.history
    loss_values = history_dict['loss']
    epochs = range(1, (len(history.history['loss']) + 1))
    acc_values = history_dict['acc']
    df = pd.DataFrame([i for i in range(1, (len(history.history['loss']) + 1))],
                      columns=["epochs"])
    df['trainLoss'] = loss_values
    df['trainAcc'] = acc_values
    df.to_csv("Train Acc_Loss for scnn5.csv", index=False)