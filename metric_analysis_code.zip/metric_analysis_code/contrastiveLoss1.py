import keras.backend as K


"""
04.24修改，加大异常数据的惩罚力度，用e指数次幂约束
"""

def contrastive_loss(y_true, y_pred):
    '''Contrastive loss from Hadsell-et-al.'06
    http://yann.lecun.com/exdb/publis/pdf/hadsell-chopra-lecun-06.pdf
    '''
    margin = 1
    sqaure_pred = K.square(y_pred)
    margin_square = (K.exp(K.square(K.maximum(margin - y_pred, 0)))-1)
    return K.mean((1-y_true) * sqaure_pred + (y_true) * margin_square)
