from keras import regularizers
from keras.optimizers import Adam, RMSprop
from keras.engine.topology import Input
from keras.layers import Activation, Add, BatchNormalization, Concatenate, \
    Conv2D, Dense, Flatten, GlobalMaxPooling2D, Lambda, MaxPooling2D, Reshape, Dropout
from keras.models import Model, Sequential
import keras.backend as K
'''
更改模型，在SCNN4网络的基础上，将l2范数网更换为头网络模型；
'''
img_shape = (64, 64, 3)
kernel_size = (3, 3)
pool_size = (2, 2)
epochs = 20
batch_size = 256
nb_filters = 32
img_rows, img_cols = 64, 64
if K.image_data_format() == 'channels_first':
    shape_ord = (3, img_rows, img_cols)
else:
    shape_ord = (img_rows, img_cols, 3)
def branch_model_CNN(shape_ord):
    model = Sequential()

    model.add(Conv2D(nb_filters, kernel_size=kernel_size, input_shape=shape_ord, name='Conv1'))
    model.add(Activation('relu', name='Act1'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling1'))

    model.add(Conv2D(2 * nb_filters, kernel_size=kernel_size, name='Conv2'))
    model.add(Activation('relu', name='Act2'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling2'))

    model.add(Conv2D(nb_filters, kernel_size=kernel_size, name='Conv3'))
    model.add(Activation('relu', name='Act3'))
    model.add(MaxPooling2D(pool_size=pool_size, strides=2, name='Maxpooling3'))

    # model.add(Dropout(0.25, name='Drop1'))

    model.add(Flatten(name='Flatten'))

    model.add(Dense(128, name='Dense1'))
    model.add(Activation('relu', name='Act4'))

    model.add(Dropout(0.5, name='Drop2'))

    model.add(Dense(50, name='Dense2'))
    return model

def euclidean_distance(vects):
    x, y = vects
    sum_square = K.sum(K.square(x - y), axis=1, keepdims=True)
    return K.sqrt(K.maximum(sum_square, K.epsilon()))

def eucl_dist_output_shape(shapes):
    shape1, shape2 = shapes
    return (shape1[0], 1)



def build_model(lr, l2, activation='sigmoid'):
    ############
    # Branch Model
    ############
    regul = regularizers.l2(l2)
    optim = Adam(lr=lr)
    kwargs = {'padding':'same', 'kernel_regularizer':regul}

    branch_model = branch_model_CNN(shape_ord)

    ############
    # HEAD MODEL
    ############
    mid = 32
    xa_inp = Input(shape=branch_model.output_shape[1:])
    xb_inp = Input(shape=branch_model.output_shape[1:])
    x1 = Lambda(lambda x: x[0] * x[1])([xa_inp, xb_inp])
    x2 = Lambda(lambda x: x[0] + x[1])([xa_inp, xb_inp])
    x3 = Lambda(lambda x: K.abs(x[0] - x[1]))([xa_inp, xb_inp])
    x4 = Lambda(lambda x: K.square(x))(x3)
    x = Concatenate()([x1, x2, x3, x4])
    x = Reshape((4, branch_model.output_shape[1], 1), name='reshape1')(x)

    # Per feature NN with shared weight is implemented using CONV2D with appropriate stride.
    x = Conv2D(mid, (4, 1), activation='relu', padding='valid')(x)
    x = Reshape((branch_model.output_shape[1], mid, 1))(x)
    x = Conv2D(1, (1, mid), activation='linear', padding='valid')(x)
    x = Flatten(name='flatten')(x)

    # Weighted sum implemented as a Dense layer.
    x = Dense(1, use_bias=True, activation=activation, name='weighted-average')(x)
    head_model = Model([xa_inp, xb_inp], x, name='head')

    ########################
    # SIAMESE NEURAL NETWORK
    ########################
    # Complete model is constructed by calling the branch model on each input image,
    # and then the head model on the resulting 512-vectors.
    img_a = Input(shape=img_shape)
    img_b = Input(shape=img_shape)
    xa = branch_model(img_a)
    xb = branch_model(img_b)
    x = head_model([xa, xb])
    model = Model([img_a, img_b], x)
    model.compile(optim, loss='binary_crossentropy', metrics=['binary_crossentropy', 'acc'])
    return model, branch_model, head_model




if __name__ == '__main__':
    print('Generate the model...')
    model, branch_model, head_model = build_model(64e-5, 0)
    def loadImage(filename):
        # first we read the image, as a raw file to the buffer
        # https://blog.csdn.net/tanlangqie/article/details/79560296
        img = Image.open(filename)
        img = np.array(img)
        return img


    from Training_Data_Utils2 import TrainingSequenceData
    from ast import literal_eval

    # 加载数据
    import pandas as pd

    data = pd.read_csv("Siamese files.csv")
    x = data['siamese pairs']
    y = data['label']
    x = x.tolist()
    y = y.tolist()
    x = [literal_eval(x[i]) for i in range(len(x))]
    for i in range(len(x)):
        for j in range(2):
            x[i][j] = x[i][j].replace('\\', '/')
    gen_all = TrainingSequenceData(x, y, batch_size=128)



    from keras.callbacks import ModelCheckpoint, ReduceLROnPlateau,EarlyStopping
    # from Training_Data_Utils import TrainingSequenceData
    from keras.optimizers import RMSprop, Adam
    from contrastiveLoss import *
    # from siameseNN3 import *
    from sklearn.model_selection import train_test_split

    # all_gen = TrainingSequenceData(batch_size=128)
    reduce_lr = ReduceLROnPlateau(monitor='loss', factor=0.5, patience=3)
    checkpoint = ModelCheckpoint('snn_model.h5', monitor='val_loss', verbose=1, save_best_only=True, mode='min')
    # early = EarlyStopping(monitor="val_loss", mode="min", patience=5)

    # callbacks_list = [reduce_lr, checkpoint, early]
    # callbacks_list = [reduce_lr, checkpoint]
    callbacks_list = [reduce_lr]


    def accuracy(y_true, y_pred):
        '''Compute classification accuracy with a fixed threshold on distances.
        '''
        return K.mean(K.equal(y_true, K.cast(y_pred > 0.5, y_true.dtype)))


    # history = model.fit_generator(all_gen, epochs=60, verbose=1,
    #                               # workers=4, use_multiprocessing=True,
    #                               callbacks=callbacks_list, steps_per_epoch=500)

    # rms = RMSprop()
    # optim = Adam(lr=64e-5)
    # model.compile(loss=contrastive_loss, optimizer=optim, metrics=[accuracy, 'mae'])
    history = model.fit_generator(gen_all, epochs=30, verbose=1,
                                  # workers=4, use_multiprocessing=True,
                                  callbacks=callbacks_list, steps_per_epoch=200)
    model.save('scnn6.h5')

    # test model
    import PIL.Image as Image
    import numpy as np
    from testImageCutting import *
    from template import template
    from matplotlib import pyplot as plt


    def loadImage(filename):
        # first we read the image, as a raw file to the buffer
        # https://blog.csdn.net/tanlangqie/article/details/79560296
        img = Image.open(filename)
        img = np.array(img)
        return img


    # 模型预测待测数据的数值
    defect_type_list = test_files_path
    test_score = [[] for i in range(len(defect_type_list))]
    for idx in range(len(defect_type_list)):
        dissimilarity_score = test_score[idx]
        for i in range(test_image[idx].shape[0]):
            score_list = []
            for j in range(template.shape[0]):
                score = model.predict([template[j].reshape(1, 64, 64, 3),
                                       test_image[idx][i].reshape(1, 64, 64, 3)])
                score_list.append(score)
            # dissimilarity_score.append(np.mean(np.array(score_list)))
            dissimilarity_score.append(np.max(np.array(score_list)))
    test_score = np.array(test_score)
    test_score = test_score.reshape(-1, 1)

    # 存储预测值与真实值
    import pandas as pd
    from test_labels import test_labels

    test_score1 = np.array([0 if test_score[i] < 0.5 else 1 for i in range(len(test_score))])
    # files_path = glob('test/*.jpg')
    files_path = []
    for i in range(62):
        for j in range(16):
            a = 'test/p_{}_{}.jpg'.format(i, j)
            files_path.append(a)

    df = pd.DataFrame([files_path[i] for i in range(len(files_path))],
                      columns=["filename"])
    df['probability'] = test_score
    df['predict label'] = test_score1
    df['real label'] = test_labels
    df.to_csv("Predict with scnn6.csv", index=False)

    # 评估模型ROC曲线：
    from test_labels import test_labels
    from Performance import Performance
    from sklearn.metrics import roc_curve, auc

    test_labels = np.array(test_labels)
    p_test = Performance(test_labels, test_score)
    p_test.get_confusion_matrix()

    fpr, tpr, threshold = roc_curve(test_labels, test_score)  ###计算真正率和假正率
    roc_auc = auc(fpr, tpr)  ###计算auc的值

    # 存储fpr值和tpr值
    df = pd.DataFrame([i for i in range(len(fpr))],
                      columns=["index"])
    df['fpr'] = fpr
    df['tpr'] = tpr
    df['threshold'] = threshold
    df.to_csv("ROC for scnn6.csv", index=False)

    # 存储训练集的损失和正确率
    history_dict = history.history
    loss_values = history_dict['loss']
    epochs = range(1, (len(history.history['loss']) + 1))
    acc_values = history_dict['acc']
    df = pd.DataFrame([i for i in range(1, (len(history.history['loss']) + 1))],
                      columns=["epochs"])
    df['trainLoss'] = loss_values
    df['trainAcc'] = acc_values
    df.to_csv("Train Acc_Loss for scnn6.csv", index=False)