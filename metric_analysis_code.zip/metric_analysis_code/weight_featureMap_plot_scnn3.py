from Siamese_Neural_Network3 import branch_model_CNN, \
    euclidean_distance, \
    eucl_dist_output_shape

'''
该模型为论文中使用的
'''
from keras.engine.topology import Input
from keras.layers import Activation, Add, BatchNormalization, Concatenate, \
    Conv2D, Dense, Flatten, GlobalMaxPooling2D, Lambda, MaxPooling2D, Reshape, Dropout
from keras.models import Model, Sequential
import keras.backend as K
# 1. Load the model
img_shape = (64, 64, 3)
kernel_size = (3,3)
pool_size = (5,5)
epochs = 20
batch_size = 256
nb_filters = 32
img_rows, img_cols = 64, 64
if K.image_data_format() == 'channels_first':
    shape_ord = (3, img_rows, img_cols)
else:
    shape_ord = (img_rows, img_cols, 3)
base_network = branch_model_CNN(shape_ord)

input_a = Input(shape=shape_ord)
input_b = Input(shape=shape_ord)
processed_a = base_network(input_a)
processed_b = base_network(input_b)

distance = Lambda(euclidean_distance,
                  output_shape=eucl_dist_output_shape)([processed_a, processed_b])

model = Model([input_a, input_b], distance)
model.load_weights('scnn3.h5')

# 2. 举例子查看网络对于
import PIL.Image as Image
import numpy as np

path_a = 'test/p_0_9.jpg'
path_b = 'test/p_0_2.jpg'
path_c = 'template/p_0_1.jpg'
path_d = 'data/Reference/p_0_1.jpg'
path_e = 'data/Reference/p_0_2.jpg'
path_f = 'data/BrokenEnd/p_0_293.jpg'
a = np.array(Image.open(path_a)).astype('float32') / 255
b = np.array(Image.open(path_b)).astype('float32') / 255
c = np.array(Image.open(path_c)).astype('float32') / 255
d = np.array(Image.open(path_d)).astype('float32') / 255
e = np.array(Image.open(path_e)).astype('float32') / 255
f = np.array(Image.open(path_f)).astype('float32') / 255
a = a.reshape((1, 64, 64, 3))
b = b.reshape((1, 64, 64, 3))
c = c.reshape((1, 64, 64, 3))
d = d.reshape((1, 64, 64, 3))
e = e.reshape((1, 64, 64, 3))
f = f.reshape((1, 64, 64, 3))

print(model.predict([a, c]))
print(model.predict([b, c]))

# 3. 卷积输出可视化
import matplotlib.pyplot as plt
def conv_output(model, layer_order, img):
    '''
    Get the output of conv layer.
    :param model: keras model
    :param layer_order: order of layer in the model
    :param img:input image
    :return: intermediate_output: feature map
    '''
    layers_list = ['Conv1', 'Act1', 'Maxpooling1',
 'Conv2', 'Act2', 'Maxpooling2',
 'Drop1', 'Flatten',  'Dense1', 'Act3', 'Drop2', 'Dense2']
    # this is the placeholder for the input images
    input_img = model.layers[2].layers[0].input
    try:
        # this is the placeholder for the conv output
        out_conv = model.layers[2].get_layer(layers_list[layer_order]).output
    except:
        raise Exception('Not layer order {}!'.format(str(layer_order)))
    # get the intermediate layer model
    intermediate_layer_model = Model(inputs = input_img, outputs = out_conv)
    # get the output of intermediate layer model
    intermediate_output = intermediate_layer_model.predict(img)

    return intermediate_output

def load_image(file_name):
    img = np.array(Image.open(file_name)).astype('float32') / 255
    return img.reshape(1, 64, 64, 3)

out = conv_output(model, 0, f)
# plt.figure(figsize=(6,3))
for _ in range(32):
    show_img = out[:, :, :, _]
    # show_img.shape = [63, 63]
    show_img.shape = [62, 62]
    plt.subplot(4, 8, _ + 1)
    # plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
    # plt.imshow(show_img, cmap='gray')
    plt.imshow(show_img)
    plt.xticks(())
    plt.yticks(())
    plt.axis('off')
    plt.tight_layout()  # 调整整体空白
    plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
    # plt.tight_layout()
plt.show()

# 4. 卷积核可视化卷积核可视化
# 解释CNN模型的另一个简单方法是显示每个卷积核响应的视觉模式, 卷积核可视化通过输入空间中的梯度上升来完成。
# 卷积核可视化的过程：我们要定义一个损失函数，这个损失函数将用于最大化某个指定滤波器的激活值。以该函数为优化目标优化后，后我们将使用随机梯度下降来调整输入图像的值，以便最大化该激活值。
import utils
def conv_filter(model, layer_order, img):
    """Get the filter of conv layer.

    Args:
           model: keras model.
           layer_name: name of layer in the model.
           img: processed input image.

    Returns:
           filters.
    """
    # this is the placeholder for the input images
    input_img = model.layers[2].layers[0].input

    # get the symbolic outputs of each "key" layer (we gave them unique names).
    layer_dict = dict([(layer.name, layer) for layer in model.layers[2].layers[0:]])
    layers_list = ['Conv1', 'Act1', 'Maxpooling1',
                   'Conv2', 'Act2', 'Maxpooling2',
                   'Drop1', 'Flatten', 'Dense1', 'Act3', 'Drop2', 'Dense2']
    layer_name = layers_list[layer_order]
    try:
        layer_output = layer_dict[layer_name].output
    except:
        raise Exception('Not layer named {}!'.format(layer_name))

    kept_filters = []
    for i in range(layer_output.shape[-1]):
        loss = K.mean(layer_output[:, :, :, i])

        # compute the gradient of the input picture with this loss
        grads = K.gradients(loss, input_img)[0]

        # normalization trick: we normalize the gradient
        grads = utils.normalize(grads)

        # this function returns the loss and grads given the input picture
        iterate = K.function([input_img], [loss, grads])

        # step size for gradient ascent
        step = 1.
        # run gradient ascent for 20 steps
        fimg = img.copy()

        for j in range(40):
            loss_value, grads_value = iterate([fimg])
            fimg += grads_value * step

        # decode the resulting input image
        fimg = utils.deprocess_image(fimg[0])
        kept_filters.append((fimg, loss_value))

        # sort filter result
        kept_filters.sort(key=lambda x: x[1], reverse=True)

    return np.array([f[0] for f in kept_filters])

a_filter = conv_filter(model, 0, a)
for _ in range(32):
    show_img = a_filter[_, :, :, :]
    # show_img.shape = [63, 63]
    show_img.shape = [64, 64, 3]
    plt.subplot(4, 8, _ + 1)
    # plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
    # plt.imshow(show_img, cmap='gray')
    plt.imshow(show_img)
    plt.xticks(())
    plt.yticks(())
    plt.axis('off')
    plt.tight_layout()  # 调整整体空白
    plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
    # plt.tight_layout()
plt.show()

# 4. 类激活图可视化
# 类激活图（CAM）可视化，包括在输入图像上产生类激活的热图。 类激活热图是与特定输出类相关联的分数的2D网格，针对任何输入图像中的每个位置计算，指示每个位置相对于所考虑的类的重要程度。例如，给定一个图像输入我们的“猫与狗”之一，类激活图可视化允许我们为类“猫”生成热图，指示图像的猫状不同部分是如何，同样对于“狗”类，表示图像的狗状不同部分。换句话时候，假设最后一层卷积层有512个卷积核，我想了解这512个卷积核对该图片是”猫”分别投了几票。投票越多的卷积核，就越确信图片是“猫”，因为它们提取到的特征趋向猫的特征。
# CAM的原理：它包括在给定输入图像的情况下获取卷积层的输出特征图，并通过目标类相对于通道的梯度对该特征图中的每个通道进行加权。简单的讲，我们获取到最后一个卷积层的卷积输出以及目标类别神经元相对于每一个通道的梯度，使用这个梯度对卷积核的每一个通道进行加权处理，最后对通道求均值并且对重要度进行归一化处理。
def output_heatmap(model, last_conv_layer, img):
    """Get the heatmap for image.

    Args:
           model: keras model.
           last_conv_layer: name of last conv layer in the model.
           img: processed input image.

    Returns:
           heatmap: heatmap.
    """
    # get the cnn model
    model = model.layers[2]
    # predict the image class
    preds = model.predict(img)
    # find the class index
    index = np.argmax(preds[0])
    # This is the entry in the prediction vector
    target_output = model.output[:, index]

    # get the last conv layer
    last_conv_layer = model.get_layer(last_conv_layer)

    # compute the gradient of the output feature map with this target class
    grads = K.gradients(target_output, last_conv_layer.output)[0]

    # mean the gradient over a specific feature map channel
    pooled_grads = K.mean(grads, axis=(0, 1, 2))

    # this function returns the output of last_conv_layer and grads
    # given the input picture
    iterate = K.function([model.input], [pooled_grads, last_conv_layer.output[0]])
    pooled_grads_value, conv_layer_output_value = iterate([img])

    # We multiply each channel in the feature map array
    # by "how important this channel is" with regard to the target class

    for i in range(conv_layer_output_value.shape[-1]):
        conv_layer_output_value[:, :, i] *= pooled_grads_value[i]

    # The channel-wise mean of the resulting feature map
    # is our heatmap of class activation
    heatmap = np.mean(conv_layer_output_value, axis=-1)
    heatmap = np.maximum(heatmap, 0)
    heatmap /= np.max(heatmap)

    return heatmap

# f_heat = output_heatmap(model, 'Conv2', f)

# 5、网络权重图
def process(x):
    return np.clip(x, 0, 1)
def deprocessed(x):
    res = np.zeros_like(x)
    res += 1
    res[x < 0] = 0
    res[x > 1] = 0
    return res
def deprocess_image(x):
    x -= x.mean()
    x /= (x.std() + 1e-5)
    x *= 0.1
    x += 0.5
    x = np.clip(x, 0, 1)
    x *= 255
    x = np.clip(x, 0, 255).astype('uint8')
    return x
def kernel_visual(model, kernel_num, layers_order, ):
    '''

    :param model: 输入的模型
    :param kernel_num: 某层卷积核数目
    :param layers_order: 某层所在的层数
    :return: 图像的列表
    '''
    kernel_1_list = []
    for i_kernal in range(kernel_num):
        input_img = model.layers[0].input
        loss = K.mean(model.layers[layers_order].output[:, :, :, i_kernal])
        # loss = K.mean(model.output[:, i_kernal])
        # compute the gradient of the input picture wrt this loss
        grads = K.gradients(loss, input_img)[0]
        # normalization trick: we normalize the gradient
        grads /= (K.sqrt(K.mean(K.square(grads))) + 1e-5)
        # this function returns the loss and grads given the input picture
        iterate = K.function([input_img, K.learning_phase()], [loss, grads])
        # we start from a gray image with some noise
        np.random.seed(0)
        # num_channels=1
        # img_height=img_width=38
        num_channels = 3
        img_height = img_width = 64
        input_img_data = (255 - np.random.randint(0, 255, (1, img_height, img_width, num_channels))) / 255.
        failed = False
        # run gradient ascent
        print('####################################', i_kernal + 1)
        loss_value_pre = 0
        for i in range(10000):
            # processed = process(input_img_data)
            # predictions = model.predict(input_img_data)
            loss_value, grads_value = iterate([input_img_data, 1])
            # grads_value *= dprocessed(input_img_data[0])
            if i % 1000 == 0:
                # print(' predictions: ' , np.shape(predictions), np.argmax(predictions))
                print('Iteration %d/%d, loss: %f' % (i, 10000, loss_value))
                print('Mean grad: %f' % np.mean(grads_value))
                if all(np.abs(grads_val) < 0.000001 for grads_val in grads_value.flatten()):
                    failed = True
                    print('Failed')
                    break
                # print('Image:\n%s' % str(input_img_data[0,0,:,:]))
                if loss_value_pre != 0 and loss_value_pre > loss_value:
                    break
                if loss_value_pre == 0:
                    loss_value_pre = loss_value

                # if loss_value > 0.99:
                #     break

            input_img_data += grads_value * 1  # e-3
        plt.subplot(kernel_num/4 , 4, i_kernal + 1)
        # plt.imshow((process(input_img_data[0,:,:,0])*255).astype('uint8'), cmap='Greys') #cmap='Greys'
        img_re = deprocess_image(input_img_data[0])
        # img_re = np.reshape(img_re, (38,38))
        img_re = np.reshape(img_re, (64, 64, 3))
        kernel_1_list.append(img_re)
        plt.imshow(img_re, cmap='Greys')  # cmap='Greys'
        plt.xticks(())
        plt.yticks(())
        plt.axis('off')
        plt.tight_layout()  # 调整整体空白
        plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
        # plt.show()
    plt.show()
    return kernel_1_list

# cnn = model.layers[2]
# a = kernel_visual(cnn, 32, 0 )

# 获取卷积层1和卷积层2的权值并绘制热力图
import seaborn as sns
cnn = model.layers[2]
conv_layer1 = cnn.layers[0].get_weights()
conv_layer2 = cnn.layers[3].get_weights()
conv_layer1_W = conv_layer1[0]
for i in range(3):
    for j in range(32):
        conv_weight = conv_layer1_W[:, :, i, j]
        plt.subplot(3, 32, 32*i + j + 1)
        sns.heatmap(conv_weight, annot=True)
        plt.xticks(())
        plt.yticks(())
        plt.axis('off')
        plt.tight_layout()  # 调整整体空白
        plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
plt.show()

kernel_channel = [[] for i in range(3)]
for i in range(3):
    # plt.subplot(1, 3, i+1)
    for j in range(32):
        conv_weight = conv_layer1_W[:, :, i, j]
        conv_weight = conv_weight.reshape(1, 9)
        kernel_channel[i].append(conv_weight)
        # plt.subplot(3, 32, 32*i + j + 1)
        # sns.heatmap(conv_weight, annot=True)
        # plt.xticks(())
        # plt.yticks(())
        # plt.axis('off')
        # plt.tight_layout()  # 调整整体空白
        # plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
kernel_channel = np.array(kernel_channel)
sns.heatmap(kernel_channel[0].reshape(32, 9), annot=True)
# plt.xticks(())
# plt.yticks(())
# plt.axis('off')
plt.tight_layout()  # 调整整体空白
plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
plt.title('HeatMap of the kernel for the 1st channel')
plt.show()
# conv_layer1_W0 = conv_layer1_W[0]
# sns.heatmap(conv_layer1_W0[:, :, 0], annot=True)
# plt.show()

# 对每个类别的评分进行分布统计，并绘制ksdensity图。